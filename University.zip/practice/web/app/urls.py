from django.contrib import admin
from django.urls import path
from . import views


urlpatterns = [
    path('',views.home),
    path('signup.html',views.signup),
    path('login',views.login),
    path('admin.html',views.admin),
    path('aboutus.html',views.about),
    path('query.html',views.query),
    path('course.html',views.course),
    path('cse.html',views.cse),
    path('ece.html',views.ece),
    path('it.html',views.it),
    path('civil.html',views.civil),
    path('contact.html',views.contact),
    
]